CPACK_DESKTOP_SHORTCUTS
-----------------------

.. versionadded:: 3.3

Species a list of shortcut names that should be created on the `Desktop`
for this file.

The property is currently only supported by the :cpack_gen:`CPack WIX Generator`.
