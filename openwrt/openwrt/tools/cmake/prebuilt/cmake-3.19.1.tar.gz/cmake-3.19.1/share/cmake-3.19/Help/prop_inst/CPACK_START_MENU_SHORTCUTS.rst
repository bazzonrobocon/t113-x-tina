CPACK_START_MENU_SHORTCUTS
--------------------------

.. versionadded:: 3.3

Species a list of shortcut names that should be created in the `Start Menu`
for this file.

The property is currently only supported by the :cpack_gen:`CPack WIX Generator`.
